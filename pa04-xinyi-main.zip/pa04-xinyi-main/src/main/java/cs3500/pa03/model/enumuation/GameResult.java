package cs3500.pa03.model.enumuation;

/**
 * represent the game result
 */
public enum GameResult {
  WIN, LOSE, DRAW
}
