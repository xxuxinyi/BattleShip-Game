package cs3500.pa04;

/**
 * Interface Battle Ship Controller
 */
public interface BattleShipController {
  void round();
}
