package cs3500.pa04;

/**
 * GameType enumeration
 */

public enum GameType {
  SINGLE,
  MULTI
}
